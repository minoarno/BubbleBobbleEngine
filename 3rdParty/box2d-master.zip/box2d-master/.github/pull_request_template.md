Pull requests for core Box2D code are generally not accepted. Please consider filing an issue instead.

However, pull requests for build system improvements are often accepted.
